# تحويل مسيرة المدرب إلى APK

تم تجهيز المشروع ليعمل كتطبيق Android باستخدام Capacitor، مع الاحتفاظ بملفات اللعبة وحفظ المسيرة محلياً على الجهاز.

## المتطلبات
- Node.js 20 أو أحدث
- Android Studio مع Android SDK
- اتصال إنترنت عند أول تثبيت للحزم

## إنشاء مشروع أندرويد وبناء APK
افتح الطرفية داخل مجلد المشروع ونفّذ:

```bash
npm install
npx cap add android
npm run build
npx cap sync android
npx cap open android
```

داخل Android Studio:
1. انتظر اكتمال Gradle Sync.
2. من القائمة اختر **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
3. بعد نجاح البناء اختر **locate** للوصول إلى ملف APK.

عادةً يكون الملف في:
`android/app/build/outputs/apk/debug/app-debug.apk`

## ملاحظات
- اسم التطبيق: مسيرة المدرب.
- معرّف التطبيق: `com.coachcareer.game`.
- ملفات الواجهة مضمنة داخل التطبيق؛ لا يحتاج تشغيل اللعبة إلى استضافة موقع.
- حفظ المسيرة يعتمد على التخزين المحلي داخل التطبيق.
- لم يتم تضمين مفتاح Gemini أو أي أسرار في المشروع.
